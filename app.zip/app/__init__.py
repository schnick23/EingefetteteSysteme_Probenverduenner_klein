﻿from .main import create_app  # Re-export für einfache Imports
